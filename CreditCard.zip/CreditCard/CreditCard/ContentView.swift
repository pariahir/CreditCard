//
//  ContentView.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var cards: ViewCard
    var body: some View {
        NavigationView{
            MasterView(cards: cards)
                .navigationBarTitle(Text("Credit Card Details"))
                .navigationBarItems(leading: EditButton(), trailing: Button(action: {
                    cards.addElement()
                }) {
                    Image(systemName: "plus")
                })
        }
    }
}


struct MasterView: View {
    @ObservedObject var cards: ViewCard
    var body: some View {
        List{
            ForEach(cards.cards, id: \.self) {cards in
                NavigationLink(destination: DetailView(card: cards),
                    label: {
                        VStack{
                            Text(cards.cardName) .font(.headline)
                            Text(cards.email) .font(.subheadline)
                                .font(.caption).italic()
                        }
                    })
        }.onDelete{(IndexSet) in
            self.cards.remove(at: IndexSet)
            }.onMove(perform: cards.move(from:to:))
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        return ContentView(cards: ViewCard())
    }
}
