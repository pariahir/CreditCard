//
//  CardViewModel.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//
import Foundation
import SwiftUI
import UIKit

class CardViewModel: ObservableObject {
    @Published var cards: Card
    
    init(cards: Card = Card(cardName: " ", description: " ", email: " "))
        {
        self.cards = cards
    }
}
