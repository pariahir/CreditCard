//
//  StructCreditCard.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//

import Foundation

class Card: Equatable, Hashable {
    static func == (lhs: Card, rhs: Card) -> Bool {
        return lhs.cardName == rhs.cardName
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(cardName)
    }
    
    
    var cardName: String
    var description: String
    var email: String
    
    init(cardName: String, description: String, email: String ) {
        self.cardName = cardName
        self.description = description
        self.email = email
    }
}

   
    
