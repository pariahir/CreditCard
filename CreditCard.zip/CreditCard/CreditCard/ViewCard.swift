//
//  ViewCard.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//

import Foundation

class ViewCard: ObservableObject {
    @Published var cards = [Card]()
    
    func  addElement() {
        let cardadd = cards.count + 1
        let card = Card(cardName: "<new>\(cardadd)", description: "<new>\(cardadd)",  email: "<new>\(cardadd)")
        cards.append(card)
        
    }
    
    func remove(at indices: IndexSet) {
        cards.remove(atOffsets: indices)
    }
    func move(from source: IndexSet, to destination: Int) {
        cards.move(fromOffsets: source, toOffset: destination)
    }
}
