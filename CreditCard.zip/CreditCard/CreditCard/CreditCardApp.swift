//
//  CreditCardApp.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//

import SwiftUI

@main
struct CreditCardApp: App {
    var cardViewModel: ViewCard {
        let cards = [Card(cardName: "Com Bank", description: """
                      This is the very nice bank,
i like this bank,
This is very safe bank.
""", email: "abc@gmail.com"),
                     
                     Card(cardName: "ANZ Bank", description: """
                     This is the very nice bank,
safe bank always.
""", email: "pqr@gmail.com"),
                     
                     Card(cardName: "NAB Bank", description: """
 this is the nice bank
""", email: "def@gmail.com")]
        
        let viewCard = ViewCard()
        viewCard.cards = cards
        return viewCard
    }
    var body: some Scene {
        WindowGroup {
            ContentView(cards: cardViewModel)
        }
    }
}
