//
//  DetailView.swift
//  CreditCard
//
//  Created by User on 9/7/21.
//

import SwiftUI

struct DetailView: View {
    @State var card: Card
    @Environment(\.editMode) var mode
    var body: some View {
        ScrollView{
            NavigationView{
                
            }.navigationBarItems(trailing: EditButton())
            if mode?.wrappedValue == .active{
                    VStack(alignment: .leading){
                        Text(card.cardName)
                            .font(.subheadline)
                            .fontWeight(.medium)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.leading)
                            .padding(.leading)
                        
                        
                        Text(card.description)
                            .font(.subheadline)
                            .fontWeight(.medium)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.leading)
                            .padding(.leading)
                        
                        Text(card.email)
                            .font(.subheadline)
                            .fontWeight(.medium)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.leading)
                            .padding(.leading)
                }
            }
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(card: Card(cardName: "Com Bank", description: """
                    This is the very nice bank,
i like this bank,
This is very safe bank.
""" , email: "abc@gmail.com"))
            .padding(.leading)
        
    }
}
